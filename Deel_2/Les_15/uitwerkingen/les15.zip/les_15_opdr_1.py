def getal_som(a, b):
    som = a + b
    return som

getal_a = int(input("Vul een getal in. "))
getal_b = int(input("Vul een getal in. "))
uitkomst = getal_som(getal_a, getal_b)
print(f"De som van {getal_a} + {getal_b} = {uitkomst}")
