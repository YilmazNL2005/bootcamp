getallen = []

for x in range(5):
    nieuw_getal = int(input("Welk getal wil je toevoegen aan de lijst? "))
    getallen.append(nieuw_getal)
    print(getallen)
