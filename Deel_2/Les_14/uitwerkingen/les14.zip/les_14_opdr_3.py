fruitsoorten = ["appel", "peer", "banaan", "sinasappel", "mango"]
print(fruitsoorten)
fruitsoort_verwijderen = input("Welk fruitsoort wil je verwijderen uit de lijst? ")
fruitsoorten.remove(fruitsoort_verwijderen)
print(fruitsoorten)