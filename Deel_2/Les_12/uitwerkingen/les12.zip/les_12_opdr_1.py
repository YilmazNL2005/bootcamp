name = input("Wat is je naam? ")
age = int(input("Wat is je leeftijd in jaren? "))
print(f"Over 5 jaar ben je {age + 5} jaar oud.")