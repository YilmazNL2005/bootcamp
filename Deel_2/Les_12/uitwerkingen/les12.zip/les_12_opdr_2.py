getal_a = int(input("Vul een getal in. "))
getal_b = int(input("Vul een getal in. "))
float(getal_a)
float(getal_b)
totaal = getal_a + getal_b
print(f"Het gemiddelde van {totaal} is {totaal / 2}")