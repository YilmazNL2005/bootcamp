woord = input("Vul een woord in. ")
lengte_woord = len(woord)
print(f"Het woord is: {woord} en bestaat uit {lengte_woord} tekens.")