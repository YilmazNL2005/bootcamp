woord_1 = input("Wat voor dag moet het zijn? ")
stad_1 = input("In welke stad was het? ")
naam_1 = input("Vul een naam in. ")
woord_3 = input("Wat zoek je? ")
woord_4 = input("Vul een geslacht in. ")
woord_5 = input("Noem een voorwerp. ")
woord_6 = input("Noem een plek. ")
woord_zin_7 = input("Vul een werkwoord in, in de wij-vorm ")


print("Het was een "+ (woord_1) +" dag in " + (stad_1) + ". " +(naam_1)+ " liep door de straten, op zoek naar " +(woord_3)+ ". Plotseling zag " +(naam_1)+ " een " +(woord_4)+ " man/vrouw die een " +(woord_5)+ " verkocht. " +(naam_1)+ " besloot om het te kopen en liep verder. Toen " +(naam_1)+ " bij een " +(woord_6)+ " kwam, zag hij/zij een groep mensen die " +(woord_zin_7)+ ". " + (naam_1) + " besloot om mee te doen en had de tijd van zijn/haar leven.")