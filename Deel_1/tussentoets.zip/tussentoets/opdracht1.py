print(6 * 3) 	# toont: 18
print(15 % 13) 	# toont: 2
print(3 / 3) 	# toont: 1
print(16 % 3)   # toont: 1
print(6 ** 3) 	# toont: 216