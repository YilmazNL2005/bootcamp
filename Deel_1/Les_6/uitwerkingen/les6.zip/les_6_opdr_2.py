a = int(input("Vul een getal in. "))
b = int(input("Vul een getal in. "))

if a > b:
    print("Variabele a is het grootst want " + str(a) + " is groter dan " + str(b))
if a < b:
    print("Variabele b is het grootst want " + str(b) + " is groter dan " + str(a))
else:
    print("Variabele a en b zijn gelijk aan elkaar.")