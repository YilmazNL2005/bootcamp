# Wat klopt er niet in deze code: Er staan haakjes 1tje op regel 2 en eentje op regel 3
# Er is geen variabel, de operator is fout want het moet == zijn
x = 18    
if x == 18:
	print('de waarde van x = 18')