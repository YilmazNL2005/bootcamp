# a=5
# b=3
# c=2
# if (a==6 and b==4 or c==2):
#    print("De conditie is waar")
# else: 
#    print("De conditie is niet waar")	

##############

# a=5
# b=3
# c=2
# if (a==6 and (b==4 or c==2)):
#    print("De conditie is waar")
# else:
#    print("De conditie is niet waar")


# Het verschil is de regel 4 en regel 14
# bij de if statement (regel 4) staat als a gelijk is aan 6 EN b is gelijk aan 4 OF c is gelijk aan 2 dan print("Conditie is waar")
# bij de if statement (regel 14) staat als a gelijk is aan 6 en 
# maar wacht. er wordt is gekeken of de b of c voldoet aan de eis om de if statement true te laten zijn dus zodat de print wordt uitgevoerd