for x in range(1,26):
    print(x)