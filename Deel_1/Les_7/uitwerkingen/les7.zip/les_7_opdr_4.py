import math

# while True:
#     getal_a = 625
#     getal_b = 12
#     berekening = getal_a / getal_b
#     afgerond_getal = math.floor(berekening)
#     print(afgerond_getal)
#     break

while True:
    berekening = 625 / 12
    afgerond_getal = math.floor(berekening)
    print(afgerond_getal)
    break