# a = 625
# b = 25
# while True:
#     berekening = a / b
#     print(berekening)
#     break

while True:
    berekening = 625 / 25
    print(berekening)
    break

# Hier staan 2 stukken code die het beiden doen.