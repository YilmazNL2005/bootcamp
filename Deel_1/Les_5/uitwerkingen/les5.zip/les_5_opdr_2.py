# Wat gebeurt hier nu weer: In de terminal wordt de string "hallo" 3x geprint
print( 3* "hallo" ) # hallohallohallo
