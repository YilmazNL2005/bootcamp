straal = int(input("Wat is de straal van de cirkel? "))
bereken_straal = straal * straal
oppervlakte_cirkel = 3.14 * bereken_straal

print("De oppervlakte van de cirkel is: " + str(oppervlakte_cirkel) + " Cm.")