# Welke operator(s) gebruik je in dit programma? = Arithmetic daarvan + 
# Verander de waarde van naam naar de naam van je buurman. 
# Werkt je programma nog steeds goed? ja

naam = "Damian"
print("hallo " + str(naam) + ", ik leer nu programmeren." )