import math

getal_a = 625
getal_b = 13
berekening = getal_a / getal_b

print(berekening) # om te checken of het goed berekend wordt.
afgerond_getal = math.floor(berekening)

print(afgerond_getal)
