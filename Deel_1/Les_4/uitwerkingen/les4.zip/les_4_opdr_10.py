sec_uur = 60 * 60
sec_dag = sec_uur * 24 #aantal seconden in een dag
sec_week = sec_dag * 7 #aantal seconden in een week
sec_jaar = sec_week * 52 #aantal seconden in een jaar

print("Er zijn "+str(sec_dag)+ " seconden in een dag.")
print("Er zijn "+str(sec_week)+ " seconden in een week.")
print("Er zijn "+str(sec_jaar)+ " seconden in een jaar.")