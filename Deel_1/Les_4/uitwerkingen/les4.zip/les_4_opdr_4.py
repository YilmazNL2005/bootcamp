# Van welk type is de variabele nu geworden (zet dat er in een commentaarregel achter).
# Werkt je programma nog steeds? = Ja het programma werkt nog steeds

naam = 252 # Type = int (integer)
print("hallo " + str(naam) + ", ik leer nu programmeren." )