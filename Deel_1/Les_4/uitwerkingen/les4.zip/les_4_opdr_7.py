print( (431 / 100) * 100 )
# Wat denk je dat eruit komt? En test het daarna eens! = 431
# Wat gebeurt hier? = het antwoord is echt op de getallen achter de komma na niet juist
