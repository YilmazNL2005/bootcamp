print( 15+4 ) # er wordt 4 bij 15 opgeteld
print( 15-4 ) # er wordt 4 van 15 afgehaald 
print( 15*4 ) # 15 keer 4
print( 15/4 ) # 15 wordt gedeeld over 4
print( 15//4 ) # 15 wordt gedeeld over 4 en het komma getal wordt afgerond naar een heel getal
print( 15**4 ) # 15 tot de macht 4
print( 15%4 ) # 15 wordt gedeeld over 4 en het resterende getal wordt in de terminal getoond.