print( 5*2 -3+4/2 )
print( 5*2 - 3+4 / 2 )
# Krijg je nu dezelfde uitkomst? Antwoord = ja

print( (5*2) - (3+4) /2 ) # de sommen die tussen de haakjes staan worden eerst berekend, daarna komt de rest met de min en gedeeld door pas.
print( ((5*2) -(3+4)) / 2 ) # de sommen die tussen de haakjes staan worden eerst berekend, daarvan de 2 uitkomsten worden van elkaar afgetrokken en tot slot wordt het gedeeld door 2.
# Vreemd, dezelfde getallen. Kun je de uitkomst verklaren? 

